import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'contacts', pathMatch: 'full' },
  { path: 'home', loadChildren: () => import('./pages/home/home.module').then(m => m.HomePageModule) },
  { path: 'contacts', loadChildren: './pages/contact-book/contact-book.module#ContactBookPageModule' },
  { path: 'contact/:id', loadChildren: './pages/contact/contact.module#ContactPageModule' },
  { path: 'add', loadChildren: './pages/add-contact/add-contact.module#AddContactPageModule' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
