import { Injectable } from '@angular/core';
import { Contact } from '../models/contact.model';

@Injectable({
  providedIn: 'root'
})
export class ContactBookService {
  private contacts: Contact[];
  constructor() {
    this.existsLocalStorage();
    localStorage.setItem('contacts', JSON.stringify(this.contacts));
  }
  public existsLocalStorage() {
    if (JSON.parse(localStorage.getItem('contacts')) != null) {
      this.contacts = JSON.parse(localStorage.getItem('contacts'));
    } else {
      this.contacts = [];
    }
  }
  public getAllContacts() {
    this.contacts = JSON.parse(localStorage.getItem('contacts'));
    return [...this.contacts];
  }
  public getContact(id: number) {
    return {
      ...this.contacts.find(contact => {
        return contact.id === id;
      })
    };
  }
  public addContact(contact: Contact) {
    this.existsLocalStorage();
    this.orderById();
    contact.id = this.getLastId();
    this.contacts.push(contact);
    this.orderByApellidoP();
    localStorage.setItem('contacts', JSON.stringify(this.contacts));
  }

  getLastId() {
    if (this.contacts != null) {
      if (this.contacts.length !== 0) {
        return this.contacts[this.contacts.length - 1].id + 1;
      } else {
        return 1;
      }
    } else {
      this.contacts = [];
      return 1;
    }
  }
  orderById() {
    this.contacts.sort((a, b) => {
      return a.id > b.id ? 1 : 0;
    });
  }
  orderByApellidoP() {
    this.contacts.sort((a, b) => {
      return a.apellido1 > b.apellido1 ? 1 : 0;
    });
  }
  existsContact(id: number) {
    let existe = false;
    this.contacts.forEach(element => {
      if (element.id == id) {
        existe = true;
      }
    });
    return existe;
  }
}
