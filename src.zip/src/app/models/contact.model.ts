export interface Contact {
    id: number;
    nombre: string;
    apellido1: string;
    apellido2: string;
    email: string;
    direccion: string;
    fijo: string;
    movil: string;
}
