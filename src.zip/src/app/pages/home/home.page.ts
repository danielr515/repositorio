import { Component, OnInit } from '@angular/core';
import { Contact } from 'src/app/models/contact.model';
import { ContactBookService } from 'src/app/services/contact-book.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {
  contacts: Contact[];
  contact: Contact = {
    id: 1,
    nombre: 'dani',
    apellido1: 'rodriguez',
    apellido2: 'iglesias',
    email: 'daniel@gmail.com',
    direccion: 'av/calle',
    fijo: '999999999',
    movil: '666666666'
  };
  constructor(private contactbook: ContactBookService) { }
  ngOnInit() {
    this.contacts = this.contactbook.getAllContacts();
    console.log(this.contacts);
  }
  onAddContact() {
    this.contactbook.addContact(this.contact);
  }
}
