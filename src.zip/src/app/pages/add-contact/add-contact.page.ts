import { Component, OnInit } from '@angular/core';
import { Contact } from 'src/app/models/contact.model';
import { ContactBookService } from 'src/app/services/contact-book.service';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.page.html',
  styleUrls: ['./add-contact.page.scss'],
})
export class AddContactPage implements OnInit {
  contacts: Contact[];
  contact: Contact;
  constructor(private contactbook: ContactBookService) { }
  ngOnInit() {
    this.contact = {
      id: 1,
      nombre: '',
      apellido1: '',
      apellido2: '',
      email: '',
      direccion: '',
      fijo: '',
      movil: ''
    };
  }
  onAddContact() {
    this.contactbook.addContact(this.contact);
  }
}
