import { Component, OnInit } from '@angular/core';
import { ContactBookService } from 'src/app/services/contact-book.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Contact } from 'src/app/models/contact.model';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.page.html',
  styleUrls: ['./contact.page.scss'],
})
export class ContactPage implements OnInit {
  contact: Contact;
  constructor(private contactbookservice: ContactBookService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    let i = parseInt(this.route.snapshot.paramMap.get('id'), 10);
    if (i) {
      if (this.contactbookservice.existsContact(i)) {
        this.contact = this.contactbookservice.getContact(i);
      } else {
        this.router.navigate(['contacts']);
      }
    } else {
      this.router.navigate(['contacts']);
    }

  }

}
