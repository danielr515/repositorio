import { Component, OnInit } from '@angular/core';
import { ContactBookService } from 'src/app/services/contact-book.service';
import { Contact } from 'src/app/models/contact.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-contact-book',
  templateUrl: './contact-book.page.html',
  styleUrls: ['./contact-book.page.scss'],
})
export class ContactBookPage implements OnInit {
  contacts: Contact[];
  iconBgColors: number[] = [];
  constructor(private contactbookservice: ContactBookService, private router: Router) { }

  ngOnInit() {
    this.contacts = this.contactbookservice.getAllContacts();
    this.getRandomBgColor();

  }
  redirector(id) {
    console.log(id);
    this.router.navigate(['/contact/' + id]);
  }
  getRandomBgColor() {
    let newNumber = 0;
    let lastNumber = 0;
    for (let i = 0; i < this.contacts.length; i++) {
      lastNumber = newNumber;
      while (newNumber == lastNumber) {
        newNumber = Math.floor(Math.random() * (13 - 1)) + 1;
      }
      this.iconBgColors.push(newNumber);
    }
  }
  gotoAddPage() {
    this.router.navigate(['/add']);
  }
}
