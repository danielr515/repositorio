import { Component, OnInit, OnChanges, AfterViewInit, AfterContentInit } from '@angular/core';
import { ContactBookService } from 'src/app/services/contact-book.service';
import { Contact } from 'src/app/models/contact.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-contact-book',
  templateUrl: './contact-book.page.html',
  styleUrls: ['./contact-book.page.scss'],
})
export class ContactBookPage implements OnInit {
  contacts: Contact[] = this.contactbookservice.getAllContacts();
  iconBgColors: number[] = [];
  constructor(private contactbookservice: ContactBookService, private router: Router) { }

  ngOnInit() {
    this.contacts = this.contactbookservice.getAllContacts();
    this.getRandomBgColor();
  }

  redirector(id) {
    console.log(id);
    this.router.navigate(['/contact/' + id]);
  }
  getRandomBgColor() {
    this.iconBgColors = [];
    let newNumber = 0;
    let lastNumber = 0;
    for (let i = 0; i < this.contacts.length; i++) {
      lastNumber = newNumber;
      while (newNumber == lastNumber) {
        newNumber = Math.floor(Math.random() * (13 - 1)) + 1;
      }
      this.iconBgColors.push(newNumber);
    }
  }
  getColor(i) {
    let clase = 'contactIcon ion-text-uppercase ';
    if (this.iconBgColors[i] == 1) {
      clase += 'bgColor1';
    } else if (this.iconBgColors[i] == 2) {
      clase += 'bgColor2';
    } else if (this.iconBgColors[i] == 3) {
      clase += 'bgColor3';
    } else if (this.iconBgColors[i] == 4) {
      clase += 'bgColor4';
    } else if (this.iconBgColors[i] == 5) {
      clase += 'bgColor5';
    } else if (this.iconBgColors[i] == 6) {
      clase += 'bgColor6';
    } else if (this.iconBgColors[i] == 7) {
      clase += 'bgColor7';
    } else if (this.iconBgColors[i] == 8) {
      clase += 'bgColor8';
    } else if (this.iconBgColors[i] == 9) {
      clase += 'bgColor9';
    } else if (this.iconBgColors[i] == 10) {
      clase += 'bgColor10';
    } else if (this.iconBgColors[i] == 11) {
      clase += 'bgColor11';
    } else if (this.iconBgColors[i] == 12) {
      clase += 'bgColor12';
    } else if (this.iconBgColors[i] == 13) {
      clase += 'bgColor13';
    }
    return clase;
  }
  getContacts() {
    if (this.contactbookservice.getAllContacts().length > this.contacts.length) {
      let count = this.contactbookservice.getAllContacts().length - this.contacts.length;
      for (count; count > 0; count--) {
        this.iconBgColors.push(Math.floor(Math.random() * (13 - 1)) + 1);
      }
    }
    this.contacts = this.contactbookservice.getAllContacts();
    return this.contacts;
  }
  gotoAddPage() {
    this.router.navigate(['/add']);
  }
}
