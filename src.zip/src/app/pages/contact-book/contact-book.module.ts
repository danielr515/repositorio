import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { ContactBookPage } from './contact-book.page';
import { ContactBookService } from 'src/app/services/contact-book.service';

const routes: Routes = [
  {
    path: '',
    component: ContactBookPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [ContactBookPage],
  providers: [ContactBookService]
})
export class ContactBookPageModule { }
